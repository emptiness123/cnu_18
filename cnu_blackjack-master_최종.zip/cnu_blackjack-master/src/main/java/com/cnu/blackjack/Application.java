package com.cnu.blackjack;

import java.util.Iterator;
import java.util.Scanner;

public class Application {
    public static void main(String[] args){
        int flag=1;
        int count;
        int betting;
        String str="";
        Scanner input=new Scanner(System.in);

        while(flag==1){
            System.out.println("덱 몇개?");
            count=input.nextInt();
            Deck deck=new Deck(count);//덱 생성
            System.out.println(deck.getTotalCard());

            Game game=new Game(deck);
            System.out.println("플레이어 수?");
            count=input.nextInt();
            for(int i=0;i<count;i++){
                input.nextLine();//버퍼 비우기
                System.out.println(i+1+"번째 이름?");
                str=input.nextLine();
                System.out.println(i+1+"번째 전재산?");
                betting=input.nextInt();
                game.addPlayer(str,betting);
            }
            //플레이어순회하면서 game의 placeBet호출하면 베팅금액 확인해주고 삭제해줌
            Iterator<String>it=game.getPlayerList().keySet().iterator();
            while(it.hasNext()){
                String a = it.next();
                System.out.println(a+"의 배팅금액?");
                betting=input.nextInt();

                game.getPlayerList().get(a).placeBet(betting);
                System.out.println( "배팅한 금액 : " + game.getPlayerList().get(a).getCurrentBet());
                System.out.println( "전재산 : " + game.getPlayerList().get(a).getBalance());
            }
            Evaluator e = new Evaluator(game.getPlayerList());

            e.start();//누가이겼는지 판가름

            System.out.println("게임 종료?y n");
            input.nextLine();
            str=input.nextLine();
            while(true){//입력 제대로 받는가?
                if(str.equals("y")){
                    flag = 0;
                    break;
                }
                if(str.equals("n")){flag=1; break;}
                    else{
                        System.out.println("다시 입력");
                        str=input.nextLine();
                    }
                }

        }
    }
}