package com.cnu.blackjack.exceptions;

public class DuplicatePlayerException extends RuntimeException {
}
