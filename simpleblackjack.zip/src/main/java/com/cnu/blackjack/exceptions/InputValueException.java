package com.cnu.blackjack.exceptions;

public class InputValueException extends RuntimeException {
}
