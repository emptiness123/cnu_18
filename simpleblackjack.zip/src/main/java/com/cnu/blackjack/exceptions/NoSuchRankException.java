package com.cnu.blackjack.exceptions;

public class NoSuchRankException extends RuntimeException {
}
