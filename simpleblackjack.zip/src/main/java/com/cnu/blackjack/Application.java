package com.cnu.blackjack;
import com.cnu.blackjack.exceptions.InputValueException;
import com.cnu.blackjack.exceptions.NotEveyonePlacedBetException;

import java.util.Map;
import java.util.Scanner;

public class Application {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Deck deck = new Deck(4);
        Game game = new Game(deck);

        while (true) {
            System.out.println("****************************");
            System.out.println("1. 플레이어 추가");
            System.out.println("2. 게임 시작");
            System.out.println("****************************");

            int inputNumber = scanner.nextInt();
            if(inputNumber == 1) {
                System.out.print("이름 입력 : ");
                String name = scanner.next();
                System.out.println("돈 입력 : ");
                int money = scanner.nextInt();
                game.addPlayer(name, money);  //입력 예외처리?
            }
            else if(inputNumber == 2) {
                break;
            }
            else throw new InputValueException();
        }

        Map<String, Player> playerList = game.getPlayerList();
        playerList.forEach((name, player) -> {
            System.out.println("배팅 금액 입력: ");
            int bet = scanner.nextInt();
            game.placeBet(name, bet);
        });
        game.setPlayerList(playerList);
        game.start();
        Evaluator evaluator = new Evaluator(game.getPlayerList());
        evaluator.start();
    }
}
