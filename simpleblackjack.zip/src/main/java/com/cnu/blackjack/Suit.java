package com.cnu.blackjack;

public enum Suit {
    SPADES, HEARTS, CLUBS, DIAMONDS;
}
