package com.cnu.blackjack.exceptions;

public class NoMoreCardException extends RuntimeException {
}
