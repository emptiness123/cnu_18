package com.cnu.blackjack;

public enum Suit {//카드 모양
    SPADES, HEARTS, CLUBS, DIAMONDS;
}
