package com.cnu.blackjack;

import java.util.Iterator;
import java.util.Scanner;

public class Application {
    public static void main(String[] args){
        int flag=1;
        int count;
        int betting;
        String str="";
        Scanner input=new Scanner(System.in);

        while(flag>0){
            System.out.println("덱 몇개?");
            count=input.nextInt();
            Deck deck=new Deck(count);//덱 생성
            System.out.println(deck.getTotalCard());

            Game game=new Game(deck);
            System.out.println("플레이어 수?");
            count=input.nextInt();
            for(int i=0;i<count;i++){
                input.nextLine();//버퍼 비우기
                System.out.println(i+1+"번째 이름?");
                str=input.nextLine();
                System.out.println(i+1+"번째 전재산?");
                betting=input.nextInt();
                game.addPlayer(str,betting);
            }


        }
    }
}