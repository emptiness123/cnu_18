package com.cnu.blackjack;

import java.util.concurrent.ThreadLocalRandom;

public class Dealer {

    public int getDealerScore() {//딜러 카드 값 뽑아내기
        ThreadLocalRandom random = ThreadLocalRandom.current();
        int score = random.nextInt(17, 25);//dealer는 17~25사이의 값을 받는다
        System.out.println(score);
        return score;
    }
}
