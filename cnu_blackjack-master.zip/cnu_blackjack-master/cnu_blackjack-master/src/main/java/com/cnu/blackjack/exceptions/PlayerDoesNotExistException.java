package com.cnu.blackjack.exceptions;

public class PlayerDoesNotExistException extends RuntimeException {
}
