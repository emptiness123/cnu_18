package com.cnu.blackjack;

import java.util.List;
import java.util.Map;

public class Evaluator {

    private Map<String, Player> playerMap;
    private Dealer dealer;

    public Evaluator(Map<String, Player> playerMap) {
        this.playerMap = playerMap;
        dealer = new Dealer();
        dealCardToPlayers();
    }

    public void start() { //카드비교해주는 역할
        int dealerNumber = getDealerNumber();
        playerMap.forEach((name, player) -> {
            checkCard(player);
            int playerNumber = getPlayerNumber(player);
            if(playerNumber == 21) {
                player.setBalance(player.getBalance() + player.getCurrentBet() * 3);
                System.out.println("Blackjack~~~");
            }
            else if(playerNumber > 21 || playerNumber == dealerNumber || playerNumber < dealerNumber) {
                System.out.println("Boom! or same same or lose");
            }
            else if(playerNumber > dealerNumber) {
                player.setBalance(player.getBalance() + player.getCurrentBet() * 2);
                System.out.println("You win");
            }
        });


    }

    private void dealCardToPlayers() {
        playerMap.forEach((name, player) -> {
            player.hitCard();
            player.hitCard();
        });
    }

    public int overten(Card card){
        if(card.getRank() > 10){
            return 10;
        }
        else {
            return card.getRank();
        }
    }
    public int getPlayerNumber(Player player) {
        int sum = 0;
        List<Card> cardList = player.getHand().getCardList();
        for(Card card : cardList) {
            sum += overten(card);
        }
        return sum;
    }

    public int getDealerNumber() {
        return dealer.getDealerScore();
    }

    public void checkCard(Player player) {
        while(getPlayerNumber(player) <= 16) {
            Card card = player.hitCard();
        }
    }

}